# m0ssion
Minimalistic extensible in-browser framework for Galaxy chat
